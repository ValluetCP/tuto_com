<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Test de l'âge de l'internaute</title>
</head>

<body>
<h1 align="center">Vous êtes arrivé sur la page acces.php</h1>
</body>
</html>
