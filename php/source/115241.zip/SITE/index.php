<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>PHP Date</title>
</head>

<body>
<?php
// Liste des variables d'accès
$debut = 1544016132;
$fin   = $debut + (3600*24*10);
$maintenant = 1544880132+1;

// Affichage des variables d'accès
echo $debut. '<br />';
echo $fin. '<br />';
echo $maintenant. '<br />';

// Test de condition d'accès
if($maintenant > $fin) {
	echo 'Acces terminé';
} else {
	echo 'Acces autorisé';
}
?>

</body>
</html>