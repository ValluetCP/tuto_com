<?php

$jours = array('mardi','jeudi','samedi','dimanche');

for($i=0; $i<=2; $i++) {
	echo $jours[$i].'<br />';
}

echo '<h1>'.$jours[2].'</h1>';