<?php
session_start();

session_destroy();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Formation Php</title>
</head>

<body>

<p align="center">
<a href="index.php">Retour index</a>
</p>

</body>
</html>