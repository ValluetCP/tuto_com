    <header>
    	<div id="headerG"><img src="media/dinosaure.png" /></div>
        <div id="headerD">Les carnivores <br /> du jurassic</div>
    </header>