    <footer>
    	<p>&copy; Les dinosaures carnivores</p>
    </footer>