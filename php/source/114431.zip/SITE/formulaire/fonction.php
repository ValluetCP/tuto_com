<?php
function champFormulaire($class,$type, $name, $placeholder) {
	echo '<input class="'.$class.'" type="'.$type.'" name="'.$name.'" placeholder="'.$placeholder.'" /> <br />';
}