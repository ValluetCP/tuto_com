$(document).ready(function() {

	$('#portfolio li').hover(function() {
		$(this).find('div.detail img').remove();
		$(this).find('img').clone().insertBefore("div.detail p").addClass("thumb");
		$(this).find('div.detail').stop(false,true).fadeIn("fast");
	},  
		function() {
		$(this).find('div.detail').stop(false,true).fadeOut("fast");
	});
	
	$("#portfolio li a").lightBox();
	
	$('.bulle').tooltipsy({
		offset: [0, 10]
	})
	
});